#include <stdio.h>
int main(){
printf("\nPart2a: \n");
printf("Name\tAge\tCountry\n_________________________\n");
printf("%s\t%d\t%s\t\n","Peter",23,"USA");
printf("%s\t%d\t%s\t\n","Manuel",43,"Germany");
printf("%s\t%d\t%s\t\n","Ken",35,"China");
printf("%s\t%d\t%s\t\n\n\n\n","Moz",44,"Ghana");


printf("\nPart2b: \n");
char chr = 67;
printf("Character having ASCII value 67 is %c.\n", chr);


printf("\nPart2c: \n");

int i_number = 12;
float f_number = 3.125;
double d_number = 7.5345345;
char character = 'T';
char text[] = "COS 135";

printf("%d, %f, %f, %c, %s\n\n", i_number, f_number, d_number, character, text);


return 0;
}
